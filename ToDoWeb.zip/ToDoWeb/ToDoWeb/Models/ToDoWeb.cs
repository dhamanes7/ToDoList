﻿using System;

namespace ToDoWeb.Models
{
    public class ToDoWeb
    {

        public object[] task { get; set; }
        

    }
}
